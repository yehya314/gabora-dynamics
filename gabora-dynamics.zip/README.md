
# 🌀 Gabora Dynamics

This is the official repository for the Generalized Collatz-Gabora Function (GCGF), a recursive dynamical system over the complex plane inspired by the classic Collatz Conjecture.

## What is the Gabora Function?

A function defined for all complex numbers:

```
G(z) = 
    z / 2                  if Re(z) mod 2 < 1
    (3z + 1) / sqrt(2)     otherwise
```

This simple rule produces stunningly complex behavior: convergence, divergence, and infinite cycles (Gabora Attractors). The system is fully documented in the included whitepaper.

## Includes

- 📘 `Gabora_Whitepaper.tex`: Full academic whitepaper in LaTeX
- 📊 `Gabora_Loop_Data.csv`: Top orbit loop data
- 🌀 `Gabora_Orbit_Frames_TypeA.csv`: Frame-by-frame animation data
- 📄 `Gabora_Formalism_Report_TypeA.txt`: Type A attractor deep analysis
- 🧠 Python code files (to be added)
- 📈 Orbit visualizations

## License

This project is open-source and revolutionarily strange. Use it wisely.

Made by Yehia Gabora & ChatGPT-4
